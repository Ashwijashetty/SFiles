# Spring Boot MySQL Example

You can learn more about my courses [here](http://courses.springframework.guru/courses/) on my site.